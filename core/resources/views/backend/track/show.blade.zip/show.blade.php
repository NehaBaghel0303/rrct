@extends('backend.layouts.track') 
@section('title', 'Track')
@section('content')


    @push('head')
    <style>
        html, body {
            height: 100%;
          }
        
        .map-container {
          width: 100%;
          height: 500px;
          max-height: 500px;
          position: relative !important;
          display: block;
        }
     
         </style>
    @endpush


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12 pr-2">
                @include('backend.track.include.vehicle-details')
            </div>
            <div class="col-lg-9 col-md-6 col-sm-12">
                <div class="card " style="background: none;box-shadow:none;">
                    <div class="card-body m-0 p-0">
                        @include('backend.track.include.vehicle-trip')
                        <div class="row">
                            <div class="col-lg-8 p-1">
                                @include('backend.track.include.map')
                            </div>
                            <div class="col-lg-4 p-1">
                                @include('backend.track.include.trip-details')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
<script>
  $('.inputChange').on('click',function(){
    alert('neha');
  })
    var asset_path = "/projects/rrct/public_html";
    var icons;

    var map;
    var markers=[];
    function initMap() {
      map = new google.maps.Map(document.getElementById('map_canvas'), {
        mapTypeControl: false,
        center: {
          lat: 16.318031,
          lng: 107.432559
        },
        zoom: 5
      });
      icons = {
      start: {
        // URL
        url:'http://maps.google.com/mapfiles/ms/micons/blue.png'},

      stopover: {
        // URL
        url: asset_path+'/frontend/map/truck-blue.png',
        // (width,height)
        size: new google.maps.Size(32, 32),
        // The origin point (x,y)
        origin: new google.maps.Point(0, 0),
        // The anchor point (x,y)
        anchor: new google.maps.Point(16, 32)},

      end: {
        // URL
        url: 'http://maps.google.com/mapfiles/ms/micons/green.png',
        // (width,height)
        size: new google.maps.Size(32, 32),
        // The origin point (x,y)
        origin: new google.maps.Point(0, 0),
        // The anchor point (x,y)
        anchor: new google.maps.Point(16, 32)}
    };

      new AutocompleteDirectionsHandler(map);
    }

    function AutocompleteDirectionsHandler(map) {
      this.map = map;
      this.originPlaceId = null;
      this.destinationPlaceId = null;
      this.destinationPlaceId2 = null;
      this.travelMode = 'DRIVING';

      var originInput = document.getElementById('start');
      var destinationInput = document.getElementById('waypoints');
      var destinationInput2 = document.getElementById('end');

      var modeSelector = document.getElementById('mode-selector');

      this.directionsService = new google.maps.DirectionsService();
      this.directionsDisplay = new google.maps.DirectionsRenderer({suppressMarkers: true});
      this.directionsDisplay.setMap(map);

      var originAutocomplete = new google.maps.places.Autocomplete(originInput, {
        fields: ['place_id']
      });
      var destinationAutocomplete2 = new google.maps.places.Autocomplete(destinationInput, {
        fields: ['place_id']
      });
      var destinationAutocomplete = new google.maps.places.Autocomplete(destinationInput2, {
        fields: ['place_id']
      });

      this.setupPlaceChangedListener(originAutocomplete, 'ORIG');
      this.setupPlaceChangedListener(destinationAutocomplete, 'DEST');
      this.setupPlaceChangedListener(destinationAutocomplete2, 'DEST2');
    }

    AutocompleteDirectionsHandler.prototype.setupClickListener = function(id, mode) {
      var radioButton = document.getElementById(id);
      var me = this;
      radioButton.addEventListener('click', function() {
        me.travelMode = mode;
        me.route();
      });
    };

    AutocompleteDirectionsHandler.prototype.setupPlaceChangedListener = function(autocomplete, mode) {
      var me = this;
      autocomplete.bindTo('bounds', this.map);
      autocomplete.addListener('place_changed', function() {
        var place = autocomplete.getPlace();
        if (!place.place_id) {
          window.alert("please input content.");
          return;
        }
        if (mode === 'ORIG') {
          me.originPlaceId = place.place_id;
        } else if (mode === 'DEST') {
          me.destinationPlaceId = place.place_id;
        } else if (mode === 'DEST2') {
          me.destinationPlaceId2 = place.place_id;
        }
        me.route();
      });
    };

    AutocompleteDirectionsHandler.prototype.route = function() {
      for (var i=0;i<markers.length; i++) {
        markers[i].setMap(null);
      }
      markers = [];
      console.log("originPlaceId=" + this.originPlaceId + " destinationPlaceId=" + this.destinationPlaceId + " destinationPlaceId2=" + this.destinationPlaceId2);

      if (!this.originPlaceId || !this.destinationPlaceId) {
        return;
      }
      var me = this;

      var waypts = [];
      if (!!this.destinationPlaceId2) {
        waypts.push({
          location: "22.80615142667948,69.68444499305794",
          stopover: true
        });
      }

      this.directionsService.route({
        origin: "24.4446659714286,72.7490266357143",
        destination: "23.826010576068555, 71.60821320849848",
        waypoints: waypts,
        optimizeWaypoints: true,
        travelMode: this.travelMode
      }, function(response, status) {
        if (status === 'OK') {
          me.directionsDisplay.setDirections(response);
          var route = response.routes[0];
          var summaryPanel = document.getElementById("directions-panel");

          // For each route, display summary information.
          summaryPanel.innerHTML = "";

          // For each route, display summary information.
          for (var i = 0; i < route.legs.length; i++) {
            var leg = route.legs[i];
            if (i===0)
              makeMarker(leg.start_location, icons.start, "title", map);
            if (i===(route.legs.length-1))
              makeMarker(leg.end_location, icons.end, 'title', map);
            else 
              makeMarker(leg.end_location, icons.stopover, 'title', map);
            var routeSegment = i + 1;
            summaryPanel.innerHTML +=
              "<b>Point:  " + routeSegment + "</b><br> Start: ";
            summaryPanel.innerHTML += route.legs[i].start_address + " </b><br> end: ";
            summaryPanel.innerHTML += route.legs[i].end_address + "<br>";
            summaryPanel.innerHTML += route.legs[i].distance.text + "<br><br>";
          }

          computeTotalDistance(response);
        } else {
          window.alert('error somewhere. ' + status);
        }
      });
    };

    function makeMarker(position, icon, title, map) {
      var marker = new google.maps.Marker({
        position: position,
        map: map,
        icon: icon,
        title: title
      });
      markers.push(marker);
    }


    function computeTotalDistance(result) {
      var totalDist = 0;
      var totalTime = 0;
      var myroute = result.routes[0];
      for (i = 0; i < myroute.legs.length; i++) {
        totalDist += myroute.legs[i].distance.value;
        totalTime += myroute.legs[i].duration.value;
      }
      totalDist = totalDist / 1000.
      document.getElementById("total").innerHTML = "Total km: " + totalDist + " km<br>Total: " + (totalTime / 60).toFixed(2) + " min";
    }


</script>
@endpush