
    <div class="card-body">
        <div class="d-flex justify-content-between mb-2">
            
            <div>
                <button type="button" id="export_button" class="btn btn-success btn-sm">Excel</button>
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Column Visibility</button>
                <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
                    <li class="dropdown-item p-0 col-btn" data-val="col_1"><a href="javascript:void(0);"  class="btn btn-sm">Vehicle Number</a></li>
                    <li class="dropdown-item p-0 col-btn" data-val="col_2">Branch<a href="javascript:void(0);"  class="btn btn-sm">Customer</a></li>
                    <li class="dropdown-item p-0 col-btn" data-val="col_3"><a href="javascript:void(0);"  class="btn btn-sm">Plant In Date/Time</a></li>
                    <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Plant Out Date/Time</a></li>
                    <li class="dropdown-item p-0 col-btn" data-val="col_5"><a href="javascript:void(0);"  class="btn btn-sm">Plan Turn Around Time</a></li>
                    <li class="dropdown-item p-0 col-btn" data-val="col_6"><a href="javascript:void(0);"  class="btn btn-sm">Trip Remark</a></li>
                </ul>
            </div>
            <input type="text" name="search" class="form-control" placeholder="Search" id="search" value="{{ request()->get('search') }}" style="width:unset;">
        </div>
        <div class="table-responsive">
            <table id="article_table" class="table table-striped">
                <thead>
                    <tr>
                        <th class="text-center" data-toggle="tooltip" data-placement="top" title="Serial Number">Sr. no.</th>
                        <th class="" data-toggle="tooltip" data-placement="top" title="Vehicle Number">Veh No.</th>
                        <th  class="col_1" data-toggle="tooltip" data-placement="top" title="Branch">Branch</th>
                        <th  class="col_4" title="Customer">Customer</th>
                        <th  class="col_2" data-toggle="tooltip" data-placement="top" title="Plant In Date/Time">Plant In Date/Time</th>
                        <th  class="col_2" data-toggle="tooltip" data-placement="top" title="Plant Out Date/Time">Plant Out Date/Time</th>
                        <th  class="col_2" data-toggle="tooltip" data-placement="top" title="Plant Turn Around Time">Plant TAT</th>
                        <th  class="col_4" data-toggle="tooltip" data-placement="top" title=" Remark">Remark</th>
                    </tr>
                </thead>
                <tbody>
                    @for ($i = 0; $i < 11; $i++)
                        <tr>
                            <td class="text-center">{{$i}}</td>
                            <td>12345</td>
                            <td>908756</td>
                            <td>{{ getFormattedDate(now()) }}</td>
                            <td>{{ 'Seoni' }}</td>
                            <td>{{ 'XYZ' }}</td>
                            <td>{{ getFormattedDate(now()) }}</td>
                            <td>{{ '--' }}</td>
                        </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-between">
        
    </div>

    {{-- Right Off Canvas --}}
    @include('backend.report.inplant.filter')
