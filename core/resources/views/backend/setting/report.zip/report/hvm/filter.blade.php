<div class="side-slide">
    <div class="">
        <div class="card-header d-flex justify-content-between">
            <h3>Filter</h3>
            <button type="button" class="close off-canvas" data-type="close">
                <span aria-hidden="true">&times;</span>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group">
                        <label>From</label>
                        <input type="date" name="from" class="form-control" value="{{request()->get('from')}}">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group"> 
                        <label>To</label>
                        <input type="date" name="to" class="form-control" value="{{ request()->get('to')}}">
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Client</label>
                        <input type="text" class="form-control" name="client" placeholder="Enter..">
                    </div>
                </div>
               
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>                               
        </div>
    </div>
</div>