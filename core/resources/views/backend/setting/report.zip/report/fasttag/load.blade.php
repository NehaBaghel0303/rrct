<div class="card-body">
    <div class="d-flex justify-content-between mb-2">
        
        <div>
            <button type="button" id="export_button" class="btn btn-success btn-sm">Excel</button>
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Column Visibility</button>
            <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
                <li class="dropdown-item p-0 col-btn" data-val="col_1"><a href="javascript:void(0);"  class="btn btn-sm">Vehicle Number</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_2">Branch<a href="javascript:void(0);"  class="btn btn-sm">LR no</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_3"><a href="javascript:void(0);"  class="btn btn-sm">Invoice no</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Branch</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Source</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Party Name</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Destination</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Total Toll Both Count</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Total FastTag Amt</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Actual Toll Both Count</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Actual FastTag Amt</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Variance/ Difference Amt</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_4"><a href="javascript:void(0);"  class="btn btn-sm">Remarks</a></li>
            </ul>
            
        </div>
        <input type="text" name="search" class="form-control" placeholder="Search" id="search" value="{{ request()->get('search') }}" style="width:unset;">
    </div>
    <div class="table-responsive">
        <table id="article_table" class="table table-striped">
            <thead>
                <tr>
                    <th class="text-center" data-toggle="tooltip" data-placement="top" title="Serial Number">Sr. no.</th>
                    <th class="" data-toggle="tooltip" data-placement="top" title="Vehicle Number">Veh No.</th>
                    <th  class="col_1" data-toggle="tooltip" data-placement="top" title="LR no">LR no</th>
                    <th  class="col_4"data-toggle="tooltip" data-placement="top"  title="Invoice no">Invoice no</th>
                    <th  class="col_2" data-toggle="tooltip" data-placement="top" title="Branch">Branch</th>
                    <th  class="col_2" data-toggle="tooltip" data-placement="top" title="Source">Source</th>
                    <th  class="col_2" data-toggle="tooltip" data-placement="top" title="Party Name">Party Name</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Destination">Destination</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Total Toll Both Count">Total Toll Both Count</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Total FastTag Amt">Total FastTag Amt</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Actual Toll Both Count">>Actual Toll Both Count</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Actual FastTag Amt">Actual FastTag Amt</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Variance/ Difference Amt">Variance/ Difference Amt</th>
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Remarks">Remarks</th>
                </tr>
            </thead>
            <tbody>
                @for ($i = 0; $i < 11; $i++)
                    <tr>
                        <td class="text-center">{{$i}}</td>
                        <td>12345</td>
                        <td>908756</td>
                        <td>{{ getFormattedDate(now()) }}</td>
                        <td>{{ 'Seoni' }}</td>
                        <td>{{ 'XYZ' }}</td>
                        <td>{{ getFormattedDate(now()) }}</td>
                        <td>{{ '--' }}</td>
                        <td>{{ '--' }}</td>
                        <td>{{ '--' }}</td>
                        <td>{{ '--' }}</td>
                        <td>{{ '--' }}</td>
                        <td>{{ '--' }}</td>
                        <td>{{ '--' }}</td>
                    </tr>
                @endfor
            </tbody>
        </table>
    </div>
</div>
<div class="card-footer d-flex justify-content-between">
    
</div>

{{-- Right Off Canvas --}}
@include('backend.report.inplant.filter')
