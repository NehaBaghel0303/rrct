<div class="card-body">
    <div class="d-flex justify-content-between mb-2">
        
        <div>
            <button type="button" id="export_button" class="btn btn-success btn-sm">Excel</button>
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Column Visibility</button>
            <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
                <li class="dropdown-item p-0 col-btn" data-val="col_1"><a href="javascript:void(0);"  class="btn btn-sm">Vehicle Number</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_2"><a href="javascript:void(0);"  class="btn btn-sm">C</a></li>
                <li class="dropdown-item p-0 col-btn" data-val="col_3"><a href="javascript:void(0);"  class="btn btn-sm">Delay</a></li>   
            </ul>
            
        </div>
        <input type="text" name="search" class="form-control" placeholder="Search" id="search" value="{{ request()->get('search') }}" style="width:unset;">
    </div>
    <div class="table-responsive">
        <table id="article_table" class="table table-striped">
            <thead>
                <tr>
                    <th class="text-center" data-toggle="tooltip" data-placement="top" title="Serial Number">Sr. no.</th>
                    <th class="" data-toggle="tooltip" data-placement="top" title="Vehicle Number">Veh No.</th>
                    <th  class="col_1" data-toggle="tooltip" data-placement="top" title="C">C</th>
                    
                    <th  class="col_4" data-toggle="tooltip" data-placement="top" title="Delay">Delay</th>
                    
                </tr>
            </thead>
            <tbody>
                @for ($i = 0; $i < 11; $i++)
                    <tr>
                        <td class="text-center">{{$i}}</td>
                        <td>12345</td>
                        <td>908756</td>
                        <td>908756</td>
                                                           
                    </tr>
                @endfor
            </tbody>
        </table>
    </div>
</div>
<div class="card-footer d-flex justify-content-between">
    
</div>

{{-- Right Off Canvas --}}
@include('backend.report.inplant.filter')
